package com.health.myapplication.data;

public class ExerciseData {
    String name;
    String desc;
    String tip;

    public ExerciseData(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }
    public ExerciseData(String name, String desc, String tip) {
        this.name = name;
        this.desc = desc;
        this.tip = tip;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
