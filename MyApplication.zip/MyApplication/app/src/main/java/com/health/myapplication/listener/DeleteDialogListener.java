package com.health.myapplication.listener;

public interface DeleteDialogListener {
    public void onPositiveClicked();
    public void onNegativeClicked();
}
