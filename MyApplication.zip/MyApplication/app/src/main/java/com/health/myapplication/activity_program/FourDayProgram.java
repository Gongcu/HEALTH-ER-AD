package com.health.myapplication.activity_program;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.health.myapplication.DbHelper.DbHelper_program;
import com.health.myapplication.R;
import com.health.myapplication.adapter.RecyclerAdapter_part;
import com.health.myapplication.data.ProgramContract;
import com.health.myapplication.dialog.ProgramDialog;
import com.health.myapplication.listener.ProgramDialogListener;

import java.util.ArrayList;

public class FourDayProgram extends AppCompatActivity {
    private static final int ACTIVITY_NUMBER=4;
    private static final boolean DATA_CHANGED=true;
    private static final int DAY_ONE=1, DAY_TWO=2, DAY_THREE=3, DAY_FOUR=4;

    private ArrayList<ArrayList<String>> group_list;
    private ArrayList<String> child_list;
    private ProgramDialog dialog;
    private RecyclerAdapter_part pAdapter, pAdapter2, pAdapter3, pAdapter4;
    private RecyclerView recyclerView, recyclerView2, recyclerView3, recyclerView4;
    private Button addButton;
    private Button button1,button2,button3,button4;
    // SQL DB의 레퍼런스
    private SQLiteDatabase mDb;
    private DbHelper_program DbHelper;

    private String part="";
    private String name="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.program_four);

        DbHelper = new DbHelper_program(this);
        mDb = DbHelper.getWritableDatabase(); //데이터에 db 채우기 위함

        initGroupData();


        recyclerView = findViewById(R.id.recyclerView);
        recyclerView2 = findViewById(R.id.recyclerView2);
        recyclerView3 = findViewById(R.id.recyclerView3);
        recyclerView4 = findViewById(R.id.recyclerView4);

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView2.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView3.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView4.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        pAdapter = new RecyclerAdapter_part(FourDayProgram.this, getData(DAY_ONE),group_list.get(0),DAY_ONE,ACTIVITY_NUMBER); //1일차 part
        recyclerView.setAdapter(pAdapter);
        pAdapter2 = new RecyclerAdapter_part(FourDayProgram.this, getData(DAY_TWO), group_list.get(1), DAY_TWO,ACTIVITY_NUMBER); //2일차 part
        recyclerView2.setAdapter(pAdapter2);
        pAdapter3 = new RecyclerAdapter_part(FourDayProgram.this, getData(DAY_THREE),group_list.get(2),DAY_THREE,ACTIVITY_NUMBER); //3일차 part
        recyclerView3.setAdapter(pAdapter3);
        pAdapter4 = new RecyclerAdapter_part(FourDayProgram.this, getData(DAY_FOUR),group_list.get(3),DAY_FOUR,ACTIVITY_NUMBER); //4일차 part
        recyclerView4.setAdapter(pAdapter4);


        addButton=findViewById(R.id.AddButton);

        button1=findViewById(R.id.button);
        button2=findViewById(R.id.button2);
        button3=findViewById(R.id.button3);
        button4=findViewById(R.id.button4);

        Button.OnClickListener onClickListener = new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()){
                    //첫번째 버튼 행동
                    case R.id.button:
                        if(recyclerView.getVisibility()==View.GONE) {
                            recyclerView.setVisibility(View.VISIBLE);
                            button1.setBackgroundDrawable(ContextCompat.getDrawable(FourDayProgram.this, R.drawable.up_btn_clicked));
                        }
                        else {
                            recyclerView.setVisibility(View.GONE);
                            button1.setBackgroundDrawable(ContextCompat.getDrawable(FourDayProgram.this, R.drawable.up_btn));
                        }
                        break;
                    //두번째 버튼 행동
                    case R.id.button2:
                        if(recyclerView2.getVisibility()==View.GONE) {
                            recyclerView2.setVisibility(View.VISIBLE);
                            button2.setBackgroundDrawable(ContextCompat.getDrawable(FourDayProgram.this, R.drawable.up_btn_clicked));
                        }
                        else {
                            recyclerView2.setVisibility(View.GONE);
                            button2.setBackgroundDrawable(ContextCompat.getDrawable(FourDayProgram.this, R.drawable.up_btn));
                        }
                        break;
                    case R.id.button3:
                        if(recyclerView3.getVisibility()==View.GONE) {
                            recyclerView3.setVisibility(View.VISIBLE);
                            button3.setBackgroundDrawable(ContextCompat.getDrawable(FourDayProgram.this, R.drawable.up_btn_clicked));
                        }
                        else {
                            recyclerView3.setVisibility(View.GONE);
                            button3.setBackgroundDrawable(ContextCompat.getDrawable(FourDayProgram.this, R.drawable.up_btn));
                        }
                        break;
                    case R.id.button4:
                        if(recyclerView4.getVisibility()==View.GONE) {
                            recyclerView4.setVisibility(View.VISIBLE);
                            button4.setBackgroundDrawable(ContextCompat.getDrawable(FourDayProgram.this, R.drawable.up_btn_clicked));
                        }
                        else {
                            recyclerView4.setVisibility(View.GONE);
                            button4.setBackgroundDrawable(ContextCompat.getDrawable(FourDayProgram.this, R.drawable.up_btn));
                        }
                        break;
                    case R.id.AddButton:
                        dialog = new ProgramDialog(FourDayProgram.this,ACTIVITY_NUMBER);
                        dialog.setDialogListener(new ProgramDialogListener() {  // DialogListener 를 구현 추상 클래스이므로 구현 필수 -> dialog의 값을 전달 받음
                            @Override
                            public void onPositiveClicked(int date, String part, String exercise,int set, int rep) {
                                addToDate(part, exercise, date, set, rep);
                                initGroupData();
                                switch (date) {
                                    case 1:
                                        pAdapter = new RecyclerAdapter_part(FourDayProgram.this, getData(DAY_ONE),group_list.get(0),DAY_ONE,ACTIVITY_NUMBER);
                                        recyclerView.setAdapter(pAdapter);
                                        break;
                                    case 2:
                                        pAdapter2 = new RecyclerAdapter_part(FourDayProgram.this, getData(DAY_TWO),group_list.get(1),DAY_TWO,ACTIVITY_NUMBER);
                                        recyclerView2.setAdapter(pAdapter2);
                                        break;
                                    case 3:
                                        pAdapter3 = new RecyclerAdapter_part(FourDayProgram.this, getData(DAY_THREE),group_list.get(2),DAY_THREE,ACTIVITY_NUMBER);
                                        recyclerView3.setAdapter(pAdapter3);
                                        break;
                                    case 4:
                                        pAdapter4 = new RecyclerAdapter_part(FourDayProgram.this, getData(DAY_FOUR),group_list.get(3),DAY_FOUR,ACTIVITY_NUMBER);
                                        recyclerView4.setAdapter(pAdapter4);
                                        break;
                                }
                            }

                        });
                        dialog.show();
                        break;
                }
            }
        };
        addButton.setOnClickListener(onClickListener);
        button1.setOnClickListener(onClickListener);
        button2.setOnClickListener(onClickListener);
        button3.setOnClickListener(onClickListener);
        button4.setOnClickListener(onClickListener);
    }

    public void addToDate(String part, String name, int date, int set, int rep) {
        Cursor c = mDb.rawQuery("select * from "+ ProgramContract.ProgramDataEntry.TABLE_NAME+" where "
                + ProgramContract.ProgramDataEntry.COLUMN_ACTIVITY+"="+ACTIVITY_NUMBER + " and "
                + ProgramContract.ProgramDataEntry.COLUMN_DATE+"="+date +" and "
                + ProgramContract.ProgramDataEntry.COLUMN_EXERCISE+"='"+name+"'", null);
        if(c.getCount()>0){
            Toast.makeText(FourDayProgram.this,"이미 같은 운동이 있습니다.",Toast.LENGTH_SHORT).show();
            c.close();
            return;
        }
        int add=0;
        ContentValues cv = new ContentValues();
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_ACTIVITY, ACTIVITY_NUMBER);
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_DATE, date);
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_PART, part);
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_EXERCISE, name);
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_SET, set);
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_REP, rep);
        for(int i=0; i<group_list.get(date-1).size(); i++){
            if(group_list.get(date-1).get(i).equals(part)) {
                add = 1;
                break;
            }
        }
        if(add==0)
            group_list.get(date-1).add(part);
        mDb.insert(ProgramContract.ProgramDataEntry.TABLE_NAME,null,cv);
    }

    private void initGroupData(){
        if(group_list!=null)
            group_list.clear();
        group_list =new ArrayList<>();
        Cursor c;
        for(int i=0; i<ACTIVITY_NUMBER; i++) {
            c = mDb.rawQuery("select " + ProgramContract.ProgramDataEntry.COLUMN_PART + " from " + ProgramContract.ProgramDataEntry.TABLE_NAME + " where " +
                    ProgramContract.ProgramDataEntry.COLUMN_ACTIVITY + "="+ACTIVITY_NUMBER+" and " + ProgramContract.ProgramDataEntry.COLUMN_DATE + "=" + (i + 1) + " group by " + ProgramContract.ProgramDataEntry.COLUMN_PART, null);
            Log.d("i", String.valueOf(c.getCount()));
            c.moveToFirst();
            child_list = new ArrayList<>();
            try {
                do {
                    child_list.add(c.getString(0));
                } while (c.moveToNext());
            }catch (CursorIndexOutOfBoundsException e){child_list.add("");} //->cursor index 오류: 없는 값을 참조하려함. try catch로 해결
            group_list.add(child_list);
        }
    }

    private Cursor getData(int date) {
        String whereClause = ProgramContract.ProgramDataEntry.COLUMN_ACTIVITY+"=? and "+ProgramContract.ProgramDataEntry.COLUMN_DATE+"=?";
        String[] whereArgs={String.valueOf(ACTIVITY_NUMBER),String.valueOf(date)};
        return mDb.query(
                ProgramContract.ProgramDataEntry.TABLE_NAME,
                null,
                whereClause,
                whereArgs,
                null,
                null,
                ProgramContract.ProgramDataEntry.COLUMN_TIMESTAMP + " DESC"
        );
    }
}
