package com.health.myapplication.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.google.android.gms.ads.AdView
import kotlinx.android.synthetic.main.activity_main.*






class MainActivity : AppCompatActivity() {
    private var mAdView: AdView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.health.myapplication.R.layout.activity_main)



        val intent = Intent(this, LoadingActivity::class.java)
        startActivity(intent)

        view1.setOnClickListener {
            val intent = Intent(this@MainActivity, ExerciseCategoryActivity::class.java)
            startActivity(intent)
        }
        view2.setOnClickListener {
            val intent = Intent(this@MainActivity, ProgramActivity::class.java)
            startActivity(intent)
        }
        view3.setOnClickListener {
            val intent = Intent(this@MainActivity, ExerciseDataActivity::class.java)
            startActivity(intent)
        }
        view4.setOnClickListener {
            val intent = Intent(this@MainActivity, CalculatorActivity::class.java)
            startActivity(intent)
        }
        view5.setOnClickListener {
            val intent = Intent(this@MainActivity, BodyWeightActivity::class.java)
            startActivity(intent)
        }
    }
}
