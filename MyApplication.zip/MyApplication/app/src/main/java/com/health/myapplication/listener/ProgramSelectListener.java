package com.health.myapplication.listener;

public interface ProgramSelectListener {
    public void onPositiveClicked(String activity);
}
