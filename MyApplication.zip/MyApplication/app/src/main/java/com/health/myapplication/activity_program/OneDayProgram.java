package com.health.myapplication.activity_program;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.health.myapplication.DbHelper.DbHelper_program;
import com.health.myapplication.R;
import com.health.myapplication.adapter.RecyclerAdapter_part;
import com.health.myapplication.data.ProgramContract;
import com.health.myapplication.dialog.ProgramDialog;
import com.health.myapplication.listener.ProgramDialogListener;

import java.util.ArrayList;

public class OneDayProgram extends AppCompatActivity {
    private static final int ACTIVITY_NUMBER=1;
    private static final boolean DATA_CHANGED=true;
    private ArrayList<ArrayList<String>> group_list;
    private ArrayList<String> child_list;
    private ProgramDialog dialog;
    private RecyclerAdapter_part pAdapter;
    RecyclerView recyclerView;
    // SQL DB의 레퍼런스
    private SQLiteDatabase mDb;
    private DbHelper_program DbHelper;

    private String part="";
    private String name="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.program_one);

        DbHelper = new DbHelper_program(this);
        mDb = DbHelper.getWritableDatabase(); //데이터에 db 채우기 위함

        initGroupData();

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        pAdapter = new RecyclerAdapter_part(OneDayProgram.this, getData(),group_list.get(0),1,ACTIVITY_NUMBER); //1일차 part
        recyclerView.setAdapter(pAdapter);



        Button Button = this.findViewById(R.id.AddButton);
        Button.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick (View view){
                dialog = new ProgramDialog(OneDayProgram.this, ACTIVITY_NUMBER);
                dialog.setDialogListener(new ProgramDialogListener() {  // DialogListener 를 구현 추상 클래스이므로 구현 필수 -> dialog의 값을 전달 받음
                    @Override
                    public void onPositiveClicked(int date, String part, String exercise, int set, int rep) {
                        addToDate(part,exercise,date,set,rep);
                        initGroupData();
                        Log.d("gro", group_list.get(0).get(0));
                        pAdapter = new RecyclerAdapter_part(OneDayProgram.this, getData(),group_list.get(0),1,ACTIVITY_NUMBER);
                        recyclerView.setAdapter(pAdapter);
                        //pAdapter.notifyChanged(DATA_CHANGED); //값이 변경되었음을 알기 위한 setter 메서드
                        //pAdapter.notifyDataSetChanged();
                    }
                });
                dialog.show();
            }
        });

        final Button button2 = findViewById(R.id.button);
        button2.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(recyclerView.getVisibility()==View.GONE) {
                    recyclerView.setVisibility(View.VISIBLE);
                    button2.setBackgroundDrawable(ContextCompat.getDrawable(OneDayProgram.this, R.drawable.up_btn_clicked));
                }
                else {
                    recyclerView.setVisibility(View.GONE);
                    button2.setBackgroundDrawable(ContextCompat.getDrawable(OneDayProgram.this, R.drawable.up_btn));
                }
            }
        });
    }

    public void addToDate(String part, String name, int date,int set, int rep) {
        Cursor c = mDb.rawQuery("select * from "+ ProgramContract.ProgramDataEntry.TABLE_NAME+" where "
                + ProgramContract.ProgramDataEntry.COLUMN_ACTIVITY+"="+ACTIVITY_NUMBER + " and "
                + ProgramContract.ProgramDataEntry.COLUMN_DATE+"="+date +" and "
                + ProgramContract.ProgramDataEntry.COLUMN_EXERCISE+"='"+name+"'", null);
        if(c.getCount()>0){
            Toast.makeText(OneDayProgram.this,"이미 같은 운동이 있습니다.",Toast.LENGTH_SHORT).show();
            c.close();
            return;
        }
        int add=0;
        ContentValues cv = new ContentValues();
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_ACTIVITY, ACTIVITY_NUMBER);
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_DATE, date);
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_PART, part);
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_EXERCISE, name);
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_SET, set);
        cv.put(ProgramContract.ProgramDataEntry.COLUMN_REP, rep);
        for(int i=0; i<group_list.get(date-1).size(); i++){
            if(group_list.get(date-1).get(i).equals(part)) {
                add = 1;
                break;
            }
        }
        if(add==0) {
            group_list.get(date - 1).add(part);
        }
        mDb.insert(ProgramContract.ProgramDataEntry.TABLE_NAME,null,cv);
    }

    private void initGroupData(){
        if(group_list!=null)
            group_list.clear();
        group_list = new ArrayList<>();

        Cursor c;
        for(int i=0; i<ACTIVITY_NUMBER; i++) {
            c = mDb.rawQuery("select *"+ " from " + ProgramContract.ProgramDataEntry.TABLE_NAME + " where " +
                    ProgramContract.ProgramDataEntry.COLUMN_ACTIVITY + "="+ACTIVITY_NUMBER+" and " + ProgramContract.ProgramDataEntry.COLUMN_DATE + "=" + (i + 1) + " group by " + ProgramContract.ProgramDataEntry.COLUMN_PART, null);
            c.moveToFirst();
            child_list = new ArrayList<>();
            try {
                do {
                    String part=c.getString(c.getColumnIndex(ProgramContract.ProgramDataEntry.COLUMN_PART));
                    child_list.add(part);
                } while (c.moveToNext());
            }catch (CursorIndexOutOfBoundsException e){e.printStackTrace();child_list.add("");} //->cursor index 오류: 없는 값을 참조하려함. try catch로 해결
            group_list.add(child_list);
        }
    }

    private Cursor getData() {
        String whereClause = ProgramContract.ProgramDataEntry.COLUMN_ACTIVITY+"=?";
        String[] whereArgs={String.valueOf(ACTIVITY_NUMBER)};
        return mDb.query(
                ProgramContract.ProgramDataEntry.TABLE_NAME,
                null,
                whereClause,
                whereArgs,
                null,
                null,
                ProgramContract.ProgramDataEntry.COLUMN_TIMESTAMP + " DESC"
        );
    }
}
