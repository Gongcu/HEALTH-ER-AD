package com.health.myapplication.listener;

public interface ProgramDialogListener {
    public void onPositiveClicked(int date,String part,String exercise, int set, int rep);
}
