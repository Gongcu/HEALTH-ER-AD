package com.health.myapplication.listener;

public interface AdapterListener {
    public void deleteSuccess();
    public void dateDeleteSuccess(String date);
}
